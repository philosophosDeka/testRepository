package com.ohgiraffers.chap01_solving;

public class Q1 {

    public static void main(String[] args) {

        int a = 20;
        int b = 30;

        System.out.println("더하기 결과 : " + (a + b));
        System.out.println("빼기 결과 : " + (a - b));
        System.out.println("곱하기 결과 : " + (a * b));
        System.out.println("나누기한 몫 : " + (a / b));
        System.out.println("나누기한 나머지 : " + (a % b));
    }
}
