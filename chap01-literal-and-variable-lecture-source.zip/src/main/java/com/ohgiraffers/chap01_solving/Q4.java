package com.ohgiraffers.chap01_solving;

public class Q4 {

    public static void main(String[] args) {

        double k = 80.5;
        double m = 50.6;
        double e = 70.8;

        int sum = (int)(k + m + e);
        System.out.println("총점 : " + sum);

        int avg = (int)(k + m + e) / 3;
        System.out.println("평균 : " + avg);
    }
}
