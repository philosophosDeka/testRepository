package com.ohgiraffers.chap01_solving;

public class Q2 {

    public static void main(String[] args) {

        double width = 12.5;    //너비
        double length = 36.4;   //높이

        double area = width * length;
        System.out.println("면적 : " + area);

        double dul = (width + length) * 2;
        System.out.println("둘레 : " + dul);
    }
}
