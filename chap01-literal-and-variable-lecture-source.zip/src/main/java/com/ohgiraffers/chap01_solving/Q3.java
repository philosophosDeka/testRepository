package com.ohgiraffers.chap01_solving;

public class Q3 {

    public static void main(String[] args) {

        char ch = 'a';
        int chNum = ch;
        System.out.println("문자 a의 unicode : " + chNum);
    }
}
